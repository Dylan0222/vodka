drop table if exists vodka_config CASCADE;

drop table if exists vodka_new_order CASCADE;

drop table if exists vodka_order_line CASCADE;

drop table if exists vodka_oorder CASCADE;

drop table if exists vodka_history CASCADE;

drop table if exists vodka_customer CASCADE;

drop table if exists vodka_stock CASCADE;

drop table if exists vodka_item CASCADE;

drop table if exists vodka_district CASCADE;
drop table if exists vodka_time CASCADE;

drop table if exists vodka_supplier CASCADE;

drop table if exists vodka_nation CASCADE;

drop table if exists vodka_region CASCADE;


drop table if exists vodka_warehouse CASCADE;


-- drop sequence vodka_hist_id_seq;

