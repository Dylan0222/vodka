SELECT COUNT(*) FILTER (where o_entry_d <  '1994-01-01 00:00:00'  )::NUMERIC / COUNT(*) FROM vodka_oorder;


