

SELECT COUNT(*) FILTER (where o_entry_d <  '1995-01-01 00:00:00')::NUMERIC / COUNT(*) FROM vodka_oorder;


