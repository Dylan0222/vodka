
truncate table vodka_warehouse;

truncate table vodka_item;

truncate table vodka_stock;

truncate table vodka_district;

truncate table vodka_customer;

truncate table vodka_history;

truncate table vodka_oorder;

truncate table vodka_order_line;

truncate table vodka_new_order;
