package metrics;

/*
 * Copyright (C) 2022, Zirui Hu, Rong Yu, Jinkai Xu, Yao Luo, Qingshuai Wang
 */
public interface Metrics {
    String DBName = "";

    public double getResult();
}