package benchmark.olap.data;

public class RegionData {
    public static Integer[] regionKey = {0, 1, 2, 3, 4};
    public static String[] regionName = {"AFRICA", "AMERICA", "ASIA", "EUROPE", "MIDDLE EAST"};

}
