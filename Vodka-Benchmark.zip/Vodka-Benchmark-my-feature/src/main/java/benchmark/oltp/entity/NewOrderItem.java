package benchmark.oltp.entity;

public class NewOrderItem {
    /* terminal input data */
    public int i_id;
    public double i_price;
    public String i_name;
    public String i_data;
}
