package benchmark.oltp.entity;

public abstract class CommonEntityData {
    @Override
    public String toString() {
        return "CommonEntityData{}";
    }
}
