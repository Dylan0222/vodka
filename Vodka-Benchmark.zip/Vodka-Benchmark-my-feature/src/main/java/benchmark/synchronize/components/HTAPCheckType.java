package benchmark.synchronize.components;

public class HTAPCheckType {
    public final static int NONE = 0,
            AD_HOC_INSERT = 1,
            AD_HOC_UPDATE = 2,
            BATCH_QUERY = 3;
}
